# AgroMath MVP (Flask + SQLite)

## Run locally
```bash
py -m pip install -r requirements.txt
py app.py
```
Open http://127.0.0.1:5000

## Notes
- OTP is demo-only (shown on screen).
- Admin phone (can approve farmers): 09066454125 (change via env `AGROMATH_ADMIN_PHONE`)
